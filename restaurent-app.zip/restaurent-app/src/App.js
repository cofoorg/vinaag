//products
import AddProducts from './components/add_products';
import Products from './components/products';
import ListProducts from './components/list_products';
import {BrowserRouter as Router,Routes,Route} from "react-router-dom";
import EditProduct from './components/edit_product';
import Navbar from './components/navbar';
import { useState } from 'react';
import "./CSS/App.css"
import Cart from './components/cart';
import AdminLogin from './components/adminLogin';
import AdminDashboard from './components/adminDashboard';
import UserHome from './components/userHome';
const App = () => {
  const [value,setvalue]=useState(1);
  const [locale,setlocale]=useState("₹");
  const [currency,setCurrency]=useState("INR");

  const SGST=9;
  const CGST=9;

  const localization=(value,locale,currency)=>{
    setvalue(value);
    setlocale(locale);
    setCurrency(currency);
  }


  
  // const [option,setOption]=useState('dine-in');
  // const options=(option)=>{
  //   setOption(option);
  // }
  // return (
  //   <div>
  //     <Router>
  //     <Navbar localization={localization}/>
  //       <Routes>
  //         <Route path='/' element={<UserHome options={options}/>}/>
  //         <Route path='/menu' element={<Products  option={option} localevalue={value} locale={locale}/>}/>
  //         {/* <Route path='/addproduct' element={<AddProducts />}/>
  //         <Route path='/listproducts' element={<ListProducts localevalue={value} locale={locale}/>}/>
  //         <Route path={`/editproducts/:id`} element={<EditProduct />}/> */}
  //         <Route path='/cart' element={<Cart localevalue={value} locale={locale} currency={currency} SGST={SGST} CGST={CGST}/>}/>
  //     </Routes>
  //     </Router>
  //   </div>
  // );

  const [adminName, setAdminName] = useState(null);
  const handleLogin = (name) => {
    setAdminName(name);
  };

  const handleLogout = () => {
    setAdminName(null);
  };

  return (
    <div>
      {adminName ? (
        <AdminDashboard adminName={adminName} onLogout={handleLogout} localization={localization} value={value} locale={locale}/>
      ) : (
        <AdminLogin onLogin={handleLogin}/>
      )}
      
      
    </div>
  );
};
export default App;