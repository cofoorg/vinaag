import React, { useState, useEffect } from 'react';
import axios from 'axios';
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Invoice from './invoice';
import Payment from './payment';

function Cart({ localevalue, locale, currency, SGST, CGST }) {
    // State for storing cart items
    const [cart, setCart] = useState([{
        name: '',
        price: '',
        description: '',
        sku: '',
        quantity: 1,
    }]);
    const [amount, setamount] = useState();
    const [today, setToday] = useState(null);

    const [orderNo, setOrderNo] = useState(() => { return parseInt(localStorage.getItem('renderCount')) || 10000; });

    var element = 0;
    var updateproduct;
    let TotalAmount = ((((SGST + CGST) / 100) * amount) + amount);




    const order = {
        orderNo: orderNo,
        date: today,
        amount: amount,
        sgst: SGST,
        cgst: CGST,
        totalAmount: TotalAmount,
        paymentMode:'',
        items: cart.map((item)=>{return item.name})
    }
    // console.log(order);

    useEffect(() => {
        setOrderNo((prevCount) => {
            const currentDate = new Date();
            const formattedDate = `${currentDate.getDate()}-${currentDate.getMonth() + 1}-${currentDate.getFullYear()}`;
            console.log(formattedDate)

            const storedDate = new Date(localStorage.getItem('date'));
            const date = `${storedDate.getDate()}-${storedDate.getMonth() + 1}-${storedDate.getFullYear()}`;
            console.log(date);
             

            if (date) {
                if (formattedDate === date) {
                    const newCount = prevCount + 1;
                    localStorage.setItem('renderCount', newCount);
                    setToday(new Date(storedDate));
                    return newCount;

                }
                else {
                    localStorage.setItem('date', currentDate);
                    localStorage.setItem('renderCount', 10000);
                    setToday(new Date(currentDate));
                    return 10000;
                }
            } else {
                localStorage.setItem('date', currentDate);
                localStorage.setItem('renderCount', 10000);
                setToday(new Date(currentDate));
                return 10000;
            }
        });
    }, [updateproduct, amount])




    useEffect(() => {

        fetchData();
        // loadData();



        //updatepostdata();

    }, [updateproduct, amount, cart]);

    const fetchData = async () => {
        const response = await axios.get("http://localhost:8080/cartproducts");
        setCart(response.data);
        setamount(sum(cart));
    }
    // const loadData=()=>{
    //     // Check if the date has changed
    //     var newDate = new Date();

    //     if (newDate !== date) {
    //         // Reset the code to initial value when the date changes
    //         setOrderNo(10000);
    //         setDate(newDate);
    //     }else{generateUniqueCode();}

    // }

    const postdata = async () => {
        await axios.post("http://localhost:8080/orders", order);
    }
    const updatepostdata = async () => {
        await axios.put(`http://localhost:8080/orders/${orderNo}`, order);
    }

    const deleteProduct = async (sku) => {
        await axios.delete(`http://localhost:8080/cart/${sku}`);
        // data();
    }

    const sum = (cart) => {
        for (let index = 0; index < cart.length; index++) {
            element = element + (cart[index].price * cart[index].quantity);
        }
        return (element);
    }

    // Function to update the quantity of a product in the cart
    const updateQuantity = async (productId, newQuantity) => {
        for (let i = 0; i < cart.length; i++) {
            if (cart[i].sku === productId) {
                updateproduct = { ...cart[i], quantity: newQuantity };

            }
        }
        if (updateproduct != null) {
            await axios.put(`http://localhost:8080/cart/${productId}`, updateproduct);
        }




    };





    // Function to render the cart items
    const renderCartItems = () => {
        return (<div className='container shadow'>
            <table className="table text-center">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Amount</th>
                        <th> </th>
                    </tr>
                </thead>
                <tbody>
                    {cart.map(item => {
                        return <>
                            <tr>
                                <td>{item.name}</td>
                                <td>{locale} {(localevalue * (item.price)).toFixed(2)}</td>
                                {/* <td>{item.quantity}</td> */}
                                <td><form><input htmlFor={item.quantity}
                                    type="number"
                                    value={item.quantity}
                                    onChange={(e) => updateQuantity(item.sku, parseInt(e.target.value))}
                                /></form></td>
                                <td>{locale} {(item.quantity * item.price * localevalue).toFixed(2)}</td>
                                <td><button className="btn btn-danger" onClick={() => deleteProduct(item.sku)}> Remove</button></td>
                            </tr></>
                    })}<tr><td></td><td colSpan={2}><b>Total Amount</b></td>
                        <td><h4>{locale} {(amount * localevalue).toFixed(2)}</h4></td><td> </td></tr>
                </tbody>
            </table>
            <div style={{ textAlign: 'center' }}>
                <button className="btn btn-warning btn-lg mx-auto mb-4" onClick={() => { postdata() }}>Next</button>
            </div></div>)

    };

    return (<div className='cart'>
        <div className='conotainer mx-5'>
            <h2 className='container pt-5 mb-3'>Cart</h2>
            {cart.length === 0 ? <div className='container border border-warning'><p className='my-auto' style={{ textAlign: 'center' }}>Your Cart is empty</p></div> : renderCartItems()}

        </div>
        <div >
            <Invoice Order={orderNo} cart={cart} localevalue={localevalue} locale={locale} />
            <Payment amount={order.totalAmount} currency={currency} />
        </div>

    </div>
    );
}

export default Cart;
