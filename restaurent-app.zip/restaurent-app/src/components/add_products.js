import React, { useState } from 'react';
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { Link,useNavigate } from 'react-router-dom';
import "../CSS/App.css";

export default function AddProducts(/*{ onAddProduct }*/) {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [sku, setSKU] = useState('');
  const [description, setDescription] = useState('');

  let navigate=useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const product={  price, sku,name, description }
    fetch("http://localhost:8080/product",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body:JSON.stringify(product)
    })
    // onAddProduct({ name, price, sku, description });
    setName('');
    setPrice('');
    setSKU('');
    setDescription('');
    navigate("/");
  };

  return (<div className='addproduct  pt-3 pb-3'>
    <div className='conatiner col-md-6 offset-md-3 border rounded p-4 shadow shadebackground'>
      <div style={{textAlign:'right'}}><button className="border" onClick={()=>navigate("/")}><b style={{color:'red'}}>X</b></button></div>
      <h1 className='text-center m-4'>Add Product</h1>
      <form onSubmit={handleSubmit} autoComplete='off'>
      <div className='mb-4'>
            <label htmlFor="name" className='form-label'>Name</label>
            <input
            type="text"
            id="name"
            name="name"
            className='form-control'
            placeholder='Enter product name'
            value={name} required
            onChange={(e) => setName(e.target.value)}
          /></div>
       <div className='mb-4'>
            <label htmlFor="price" className='form-label'>Price</label>
            <input
            type="text"
            id="price"
            name="price"
            className='form-control'
            placeholder='Price in Rupees'
            value={price} required
            onChange={(e) => setPrice(e.target.value)}
          /></div>
       <div className='mb-4'>
            <label htmlFor="description" className='form-label'>Description</label>
            <textarea
            id="description"
            name="description"
            className='form-control'
            placeholder='Product Description'
            value={description}
            onChange={(e) => setDescription(e.target.value)}
          /></div>
          
          <div className='mb-4'>
            <label htmlFor="sku" className='form-label'>SKU</label>
            <input
            type="text"
            id="sku"
            name="sku"
            className='form-control'
            placeholder='Stock Keeping Unit'
            value={sku} required
            onChange={(e) => setSKU(e.target.value)}
          /></div>
        <div className='mb-4'><button className="submit form-control btn btn-primary" type="submit">Submit</button>
        <Link to={"/"} className='form-control btn btn-outline-danger mt-3'>Cancel</Link></div>
        {/* <label>Enter multiple items</label>
        <input type='radio'/> */}
             
      </form>
    </div></div>
  );
};
