import React, { useState, useEffect } from 'react';
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../CSS/App.css";
import axios from 'axios';

export default function Products({ option,localevalue, locale }) {
  const [products, setProducts] = useState([{
    name: '',
    price: '',
    description: '',
    sku: '',
    quantity: 1
  }]);

  const addtocart = (product) => {
    fetch("http://localhost:8080/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(product)
    })
  }

  const updateQuantity = (productId, newQuantity) => {
    const updatedproduct = products.map(item => {
      if (item.sku === productId) {
        return { ...item, quantity: newQuantity };
      }
      return item;

    });
    setProducts(updatedproduct);

  };

  const [displayText, setDisplayText] = useState('');

  const handleClick = () => {
    setDisplayText('Button clicked!');
    setTimeout(() => {
      setDisplayText('');
    }, 3000); // Display text for 3 seconds
  };


  // useEffect(()=>{
  //   fetch("http://localhost:8080/allproducts")
  //   .then(res=>res.json())
  //   .then((result)=>setProducts(result));

  //   const updatedproduct=products.map(item => {
  //     return { ...item, quantity: 1 };
  // });
  // setProducts(updatedproduct);
  //   console.log('true')
  // },[])

  useEffect(() => {
    const response = axios.get("http://localhost:8080/allproducts");
    response.then((response) => {
      setProducts(response.data);
    })
    // setTimeout(()=>updatequantity(),1000);
    
  },[option])

  const updatequantity = () => {
    const updatedproduct = products.map(item => {
      return { ...item, quantity: 1 };
    });
    setProducts(updatedproduct);
    console.log(products);
  }

  return (
    <div className="background app">
      <h1 className='pt-5 mb-3' style={{ color: 'grey' }}>Restaurant Menu</h1>
      <div className="menu pb-5">

        {products.map((product, index) => (
          <div key={index} className="product-card">
            <h3>{product.name}</h3>
            <p>Price: <b>{locale}</b> {(localevalue * (product.price)).toFixed(2)}</p>
            <p>SKU: {product.sku}</p>
            <p>Description: {product.description}</p>
            <div className='d-flex'><p className='my-auto'>Select quantity : </p>
              <input
                htmlFor={product.quantity}
                type="number"
                value={product.quantity} onChange={(e) => updateQuantity(product.sku, parseInt(e.target.value))}
              /></div><br />
            <button className='btn btn-primary' onClick={() => { addtocart(product); handleClick() }}>Add to cart</button>{displayText && <p>{displayText}</p>}
          </div>
        ))}

      </div>
    </div>
  );
};

