import { useEffect, useState } from "react";
import Axios from "axios";
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { useNavigate } from "react-router-dom";
import "../CSS/App.css";


export default function ListProducts({localevalue,locale}) {

    const [products, setProducts] = useState([]);
    const navigate = useNavigate();


    useEffect(() => {
        fetch("http://localhost:8080/allproducts")
            .then(res => res.json())
            .then((result) => setProducts(result))
    }, [products]);

    const deleteproduct = async (sku,name) => {
        if(window.confirm("Delete "+name+" ...?")){
            await Axios.delete(`http://localhost:8080/product/${sku}`);
        }
        navigate("/");
    }

    const editproduct = (sku) => {
        navigate(`/editproducts/${sku}`);
    }

    return (<div className="listproducts pt-3 pb-3">
        <div className="container shadebackground pb-2" >
            <h1 className="mt-5 mb-3">Products List</h1>
            <table className="table border shadow text-center" >
                <thead>
                    <tr><th>Name</th>
                        <th>Price</th>
                        <th>SKU</th>
                        <th>Description</th>
                        <th colSpan={2}>Action</th>
                    </tr></thead>
                <tbody>
                    {products.map((product, index) => (
                        <tr>
                            <td key={index.name}>{product.name}</td>
                            <td key={index.price}><b>{locale}</b> {(product.price*localevalue).toFixed(2)}</td>
                            <td key={index.sku}>{product.sku}</td>
                            <td key={index.description}>{product.description}</td>
                            <td><button className="btn btn-success mx-3 " onClick={() => editproduct(product.sku)}>Edit</button>
                                <button className="btn btn-danger" onClick={() => deleteproduct(product.sku,product.name)}>Delete</button></td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div></div>
    )
}