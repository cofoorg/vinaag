// AdminDashboard.js
import React from 'react';
import Navbar from './adminNavbar';
import ListProducts from './list_products';
import EditProduct from './edit_product';
import {BrowserRouter as Router,Routes,Route } from 'react-router-dom';
import AddProducts from './add_products';
import Orders from './orders';
import Employees from './employees';

const AdminDashboard = ({ adminName ,onLogout,localization,value,locale}) => {
  return (
    <div>
        <Router>
        <Navbar localization={localization} onLogout={onLogout}/>
            <Routes>
                <Route path='/' element={<ListProducts localevalue={value} locale={locale}/>}/>
                <Route path='/addproduct' element={<AddProducts/>}/>
                <Route path='/employees' element={<Employees/>}/>
                <Route path='/orders' element={<Orders localevalue={value} locale={locale}/>}/>
                <Route path={`/editproducts/:id`} element={<EditProduct />}/>
            </Routes>
        </Router>
        
      
    </div>
  );
};

export default AdminDashboard;
