import React from "react";
import { Link } from "react-router-dom";
import Main from "./apicalling";

export default function Navbar({localization,onLogout}) {
    return (
        <nav className="navbar navbar-expand-lg bg-light">
            <div className="container-fluid">
                <Link className="navbar-brand" to={"/"}><h2>Navbar</h2></Link>
                <div style={{display:"flex"}}>
                <Link to={"/"} className="btn btn-outline-dark mx-2">Products List</Link>
                <Link to={"/addproduct"} className="btn btn-outline-dark mx-2">Add Products</Link>
                <Link to={"/employees"} className="btn btn-outline-dark mx-2">Employees</Link>
                <Link to={"/orders"} className="btn btn-outline-dark mx-2">Track Orders</Link>
                {/* <Main localization={localization}/> */}
                <button className="mx-2 my-auto" onClick={onLogout}>Log Out</button>
                </div>
            </div>
        </nav>
    )

}