import React, { useState } from 'react';
import '../../node_modules/bootstrap/dist/css/bootstrap.min.css';

const AdminLogin = ({ onLogin }) => {
  const [adminName, setAdminName] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Validate admin credentials (you should replace this with your actual authentication logic)
    if (adminName === 'admin' && password === 'password') {
      onLogin(adminName);
    } else {
      alert('Invalid credentials');
    }
  };

  return (<div>
    <div className='container shadow col-lg-6 my-5' style={{textAlign:'center',background:"linear-gradient(to right, #ff7e5f, #feb47b, #ffefa1)"}}>
      <h2>Admin Login</h2><form className='col-lg-6 mx-auto'>
      <div className='form-label my-2'><label>Admin Name</label>
      <input
        type="text"
        placeholder="Admin Name"
        className='form-control'
        value={adminName}
        onChange={(e) => setAdminName(e.target.value)}
      /></div>
      <div><label className='form-label my-2'>Password</label>
      <input
        type="password"
        placeholder="Password"
        className='form-control'
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      /></div>
      <button className='btn btn-info my-4' onClick={handleLogin}>Login</button></form>
    </div></div>
  );
};

export default AdminLogin;