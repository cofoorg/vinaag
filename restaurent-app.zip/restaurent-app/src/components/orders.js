import React, { useEffect, useState } from 'react';
import "../../node_modules/bootstrap/dist/css/bootstrap.min.css"
import "../CSS/App.css";
import axios from 'axios';

const Orders = ({localevalue,locale}) => {
  const [orders, setOrders] = useState([{
    invoiceNo:'',
    orderNo:'',
    date:'',
    amount:'',
    sgst:'',
    cgst:'',
    totalAmount:'',
    paymentMode:'',
    items:''
  }]);

  useEffect(()=>{
    const response =axios.get("http://localhost:8080/allOrders");
    response.then((response)=>{
      setOrders(response.data);
      console.log(orders);
    })
  },[])

  return (<div className='orders pt-4 pb-4'>
    <div className='container shadow mx-auto pb-2 shadebackground'>
      <h2>Orders Transactions</h2>
      <table className='table mx-auto'>
        <thead>
          <tr>
            <th>Invoice No</th>
            <th>Order Number</th>
            <th>Date</th>
            <th>Payment Mode</th>
            <th>Ordered Items</th>
            <th>Total Price</th>
          </tr>
        </thead>
        <tbody>
          {orders.map(order => (
            <tr>
              <td>{order.invoiceNo}</td>
              <td>{order.orderNo}</td>
              <td>{order.date}</td>
              <td>{order.paymentMode}</td>
              <td>{(order.items)}</td>
              <td>{locale} {localevalue*order.totalAmount}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div></div>
  );
};

export default Orders;