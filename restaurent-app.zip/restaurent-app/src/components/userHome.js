import React from "react";
import { Link } from "react-router-dom";
import dineinimage from "../Images/dineinimage.jpg"
import takeawayimage from "../Images/takeaway.jpg"
import "../CSS/App.css";
import { useNavigate } from "react-router-dom";

export default function UserHome({options}) {
    let navigate=useNavigate();
    return <div className="container my-5 background">
        <div className="container shadow my-4 col-md-10 col-lg-6">
            <div className="container" style={{ textAlign: 'center', display: "flex", alignItems: 'center' }}>
                <div onClick={()=>options('dine-in')}><button onClick={()=>{options('take-away');navigate('/menu')}}><img  className='btn' src={dineinimage} /></button><Link to={`/menu`} className="btn btn-lg btn-success my-4 mx-4">Dine-In</Link></div>
                <div onClick={()=>options('take-away')} className="my-4"><button onClick={()=>{options('take-away');navigate('/menu')}}><img  className='btn' src={takeawayimage} /></button><Link to={'/menu'} className="btn btn-lg btn-danger my-4 mx-4">Take-Away</Link></div>
            </div>

        </div>
    </div>
}